import { useState } from "react";

const COMP_TYPES = [
  { id: "kasbiy", label: "Kasbiy kompetentlik", short: "Kasbiy", hex: "#1e40af", bg: "#dbeafe", icon: "ti-briefcase" },
  { id: "kommunikativ", label: "Kommunikativ kompetentlik", short: "Kommunikativ", hex: "#166534", bg: "#dcfce7", icon: "ti-message-circle" },
  { id: "raqamli", label: "Axborot-raqamli kompetentlik", short: "Raqamli", hex: "#5b21b6", bg: "#ede9fe", icon: "ti-device-laptop" },
  { id: "ijtimoiy", label: "Ijtimoiy-shaxsiy kompetentlik", short: "Ijtimoiy", hex: "#92400e", bg: "#fef3c7", icon: "ti-users" },
  { id: "ilmiy", label: "Ilmiy-tadqiqotchilik kompetentlik", short: "Ilmiy", hex: "#9d174d", bg: "#fce7f3", icon: "ti-microscope" },
];

const INIT_TESTS = [
  {
    id: 1, title: "Raqamli savodxonlik", comp: "raqamli", time: 15, published: true,
    desc: "Raqamli texnologiyalar va internet savodxonligi bo'yicha test",
    questions: [
      { id: 1, type: "single", text: "Quyidagi dasturlardan qaysi biri matn muharriri hisoblanadi?", options: ["Microsoft Word", "Adobe Photoshop", "VLC Media Player", "WinRAR"], correct: [0], score: 2 },
      { id: 2, type: "single", text: "Brauzer deb nimaga aytiladi?", options: ["Operatsion tizim", "Internet sahifalarini ko'rish dasturi", "Antivirus dasturi", "Grafik muharrir"], correct: [1], score: 2 },
      { id: 3, type: "multi", text: "Quyidagilardan qaysilari bulut xizmatlariga misol bo'ladi?", options: ["Google Drive", "USB flesh-xotira", "Dropbox", "CD disk", "OneDrive"], correct: [0, 2, 4], score: 3 },
      { id: 4, type: "truefalse", text: "Wi-Fi va Bluetooth bir xil texnologiya hisoblanadi.", options: ["To'g'ri", "Noto'g'ri"], correct: [1], score: 2 },
      { id: 5, type: "single", text: "Phishing hujumi nima?", options: ["Kompyuterni tezlashtirish", "Aldov yo'li bilan ma'lumot o'g'irlash", "Dasturiy ta'minot yangilash", "Tarmoq tezligini o'lchash"], correct: [1], score: 3 },
    ],
  },
  {
    id: 2, title: "Kasbiy etika", comp: "kasbiy", time: 20, published: true,
    desc: "Mutaxassislik sohasida kasbiy etika va axloq normalari",
    questions: [
      { id: 1, type: "single", text: "Kasbiy etika asosiy qoidasi qaysi?", options: ["Faqat o'z manfaatini ko'zlash", "Kasb sharafini saqlash va halollik", "Raqobatchilarni yo'q qilish", "Boshqalar xatosidan foydalanish"], correct: [1], score: 2 },
      { id: 2, type: "truefalse", text: "Ish joyida shaxsiy muammolarni hal qilish etikaga zid emas.", options: ["To'g'ri", "Noto'g'ri"], correct: [1], score: 2 },
      { id: 3, type: "single", text: "Konfidensiallik prinsipi nimani anglatadi?", options: ["Ma'lumotlarni hamma bilan ulashish", "Mijoz ma'lumotlarini sir saqlash", "Ishdan bosh tortish", "Yordam berishni rad etish"], correct: [1], score: 3 },
      { id: 4, type: "multi", text: "Kasbiy axloq kodeksiga kiritilishi kerak bo'lgan tamoyillar:", options: ["Halollik", "Tarafkashlik", "Mas'uliyatlilik", "Shaxsiy manfaat", "Vakolatlilik"], correct: [0, 2, 4], score: 3 },
      { id: 5, type: "single", text: "Korrupsiyaga qarshi kurashda mutaxassisning vazifasi:", options: ["Jim o'tish", "Rad etish va xabar berish", "Qatnashish", "Boshqa ish topish"], correct: [1], score: 3 },
    ],
  },
  {
    id: 3, title: "Ilmiy muloqot", comp: "kommunikativ", time: 25, published: true,
    desc: "Ilmiy jamoa va jamoat oldida samarali muloqot ko'nikmalari",
    questions: [
      { id: 1, type: "single", text: "Ilmiy maqolaning to'liq tuzilishi qanday?", options: ["Sarlavha, abstrakt, kontent, xulosa", "Kirish, asosiy qism, xulosa", "Kirish, metodologiya, natijalar, muhokama, xulosa", "Faqat natijalar va xulosa"], correct: [2], score: 2 },
      { id: 2, type: "truefalse", text: "Plagiat ilmiy etikaga mutlaqo zid.", options: ["To'g'ri", "Noto'g'ri"], correct: [0], score: 2 },
      { id: 3, type: "single", text: "Prezentatsiyada qaysi qoida tavsiya etiladi?", options: ["Imkon qadar ko'p slayd", "1 daqiqa — 1 slayd qoidasi", "Faqat 3 ta slayd", "Slaydlar soni muhim emas"], correct: [1], score: 2 },
      { id: 4, type: "multi", text: "Samarali ilmiy doklad uchun muhim elementlar:", options: ["Aniq maqsad", "Hajmli matn bloklari", "Vizual materiallar", "Vaqtga rioya", "Jargonlar"], correct: [0, 2, 3], score: 3 },
      { id: 5, type: "single", text: "Peer-review jarayonida maqola qanday baholanadi?", options: ["Muallif tanishlari tomonidan", "Soha mutaxassislari anonim ravishda", "Tahririyat kotibi tomonidan", "Avtomatik dasturlar orqali"], correct: [1], score: 3 },
    ],
  },
];

const INIT_LINKS = [
  { id: 1, title: "Moodle LMS", url: "https://moodle.org", icon: "ti-school", color: "#f97316", bg: "#fff7ed", desc: "Onlayn kurs va vazifalar platformasi" },
  { id: 2, title: "Google Classroom", url: "https://classroom.google.com", icon: "ti-brand-google", color: "#4285f4", bg: "#eff6ff", desc: "Google ta'lim platformasi" },
  { id: 3, title: "Zoom", url: "https://zoom.us", icon: "ti-video", color: "#2d8cff", bg: "#eff6ff", desc: "Video darslar va uchrashuvlar" },
  { id: 4, title: "YouTube Education", url: "https://youtube.com/education", icon: "ti-brand-youtube", color: "#ff0000", bg: "#fff1f2", desc: "Ta'lim video materiallari" },
  { id: 5, title: "Khan Academy", url: "https://khanacademy.org", icon: "ti-trending-up", color: "#1aad19", bg: "#f0fdf4", desc: "Bepul onlayn kurslar" },
];

function getComp(id) { return COMP_TYPES.find((c) => c.id === id) || COMP_TYPES[0]; }
function fmtTime(s) { const m = Math.floor(s / 60), sc = s % 60; return `${m}:${sc < 10 ? "0" : ""}${sc}`; }
function initials(u) { return (u.ism[0] || "") + (u.familiya[0] || ""); }
function now() { const d = new Date(); return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}`; }

const s = { fontSize: 13, color: "#64748b" };
const badge = (color, bg, text) => (
  <span style={{ background: bg, color, fontSize: 12, padding: "3px 10px", borderRadius: 20, fontWeight: 500, display: "inline-flex", alignItems: "center", gap: 4 }}>{text}</span>
);

export default function App() {
  const [page, setPage] = useState("login");
  const [role, setRole] = useState(null);
  const [user, setUser] = useState(null);
  const [tests, setTests] = useState(JSON.parse(JSON.stringify(INIT_TESTS)));
  const [links, setLinks] = useState(JSON.parse(JSON.stringify(INIT_LINKS)));
  const [results, setResults] = useState([]);
  const [activeTest, setActiveTest] = useState(null);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [timerRef, setTimerRef] = useState(null);
  const [lastResult, setLastResult] = useState(null);
  const [adminTab, setAdminTab] = useState("tests");
  const [createMode, setCreateMode] = useState(false);
  const [newTest, setNewTest] = useState(null);
  const [loginRole, setLoginRole] = useState("student");
  const [searchQ, setSearchQ] = useState("");
  const [compFilter, setCompFilter] = useState("");
  const [showAddLink, setShowAddLink] = useState(false);
  const [newLink, setNewLink] = useState({ title: "", url: "", desc: "" });

  const go = (pg) => setPage(pg);
  const myResults = () => results.filter((r) => r.userId === user?.ism);

  const doLogin = (nm, fm, gr, yn) => {
    if (loginRole === "admin") {
      setUser({ ism: "Admin", familiya: "Karimov", guruh: "", yonalish: "" });
    } else {
      setUser({ ism: nm || "Aziz", familiya: fm || "Toshmatov", guruh: gr || "IT-22", yonalish: yn || "Axborot texnologiyalari" });
    }
    setRole(loginRole);
    setPage("dashboard");
  };

  const logout = () => { setUser(null); setRole(null); setPage("login"); };

  const startTest = (id) => {
    const t = tests.find((t) => t.id === id);
    setActiveTest(t);
    setAnswers({});
    setTimeLeft(t.time * 60);
    if (timerRef) clearInterval(timerRef);
    const ref = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) { clearInterval(ref); return 0; }
        return prev - 1;
      });
    }, 1000);
    setTimerRef(ref);
    setPage("test-take");
  };

  const selectOpt = (qi, oi, isMulti) => {
    setAnswers((prev) => {
      const cur = prev[qi] || [];
      if (isMulti) {
        return { ...prev, [qi]: cur.includes(oi) ? cur.filter((x) => x !== oi) : [...cur, oi] };
      }
      return { ...prev, [qi]: [oi] };
    });
  };

  const submitTest = () => {
    if (timerRef) clearInterval(timerRef);
    const t = activeTest;
    let score = 0, max = 0;
    const detail = t.questions.map((q, qi) => {
      max += q.score;
      const ans = answers[qi] || [];
      const ok = ans.length === q.correct.length && q.correct.every((c) => ans.includes(c));
      if (ok) score += q.score;
      return { text: q.text, ans, correct: q.correct, ok, options: q.options, score: q.score };
    });
    const pct = Math.round((score / max) * 100);
    const result = { testId: t.id, userId: user.ism, title: t.title, comp: t.comp, score, max, pct, date: now(), detail };
    setResults((prev) => [...prev, result]);
    setLastResult(result);
    setPage("result");
  };

  const radarSVG = (res, size = 160) => {
    const cx = size / 2, cy = size / 2, r = size / 2 - 28;
    const scores = COMP_TYPES.map((c) => {
      const rs = res.filter((x) => x.comp === c.id);
      return rs.length ? Math.round(rs.reduce((a, b) => a + b.pct, 0) / rs.length) : 0;
    });
    const pts = COMP_TYPES.map((_, i) => {
      const a = (i * 2 * Math.PI) / 5 - Math.PI / 2;
      const rv = r * (scores[i] / 100);
      return [cx + rv * Math.cos(a), cy + rv * Math.sin(a)];
    });
    const poly = pts.map((p) => p.join(",")).join(" ");
    const rings = [0.25, 0.5, 0.75, 1].map((f, ri) => {
      const rpts = COMP_TYPES.map((_, i) => {
        const a = (i * 2 * Math.PI) / 5 - Math.PI / 2;
        return `${cx + r * f * Math.cos(a)},${cy + r * f * Math.sin(a)}`;
      }).join(" ");
      return <polygon key={ri} points={rpts} fill="none" stroke="#e2e8f0" strokeWidth="0.5" />;
    });
    const axes = COMP_TYPES.map((c, i) => {
      const a = (i * 2 * Math.PI) / 5 - Math.PI / 2;
      const lx = cx + (r + 20) * Math.cos(a), ly = cy + (r + 20) * Math.sin(a);
      return (
        <g key={i}>
          <line x1={cx} y1={cy} x2={cx + r * Math.cos(a)} y2={cy + r * Math.sin(a)} stroke="#e2e8f0" strokeWidth="0.5" />
          <text x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontSize={9} fill="#64748b">{c.short}</text>
        </g>
      );
    });
    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {rings}{axes}
        <polygon points={poly} fill="rgba(30,64,175,0.12)" stroke="#1e40af" strokeWidth="2" />
        {pts.map((p, i) => (
          <g key={i}>
            <circle cx={p[0]} cy={p[1]} r={4} fill="#1e40af" />
            {scores[i] > 0 && <text x={p[0]} y={p[1] - 8} textAnchor="middle" fontSize={9} fill="#1e40af" fontWeight="500">{scores[i]}%</text>}
          </g>
        ))}
      </svg>
    );
  };

  const PAGE_TITLES = { login: "Kirish", register: "Ro'yxatdan o'tish", dashboard: "Dashboard", tests: "Testlar", "test-take": "Test ishlash", result: "Natija", profile: "Kompetensiya profili", resources: "Foydali resurslar", stats: "Statistika", admin: "Boshqaruv paneli" };

  const Sidebar = () => {
    const isAdmin = role === "admin";
    const nav = isAdmin
      ? [{ icon: "ti-layout-dashboard", label: "Dashboard", pg: "dashboard" }, { icon: "ti-clipboard-list", label: "Testlar boshqaruvi", pg: "admin" }, { icon: "ti-chart-bar", label: "Statistika", pg: "stats" }, { icon: "ti-link", label: "Havolalar", pg: "resources" }]
      : [{ icon: "ti-layout-dashboard", label: "Dashboard", pg: "dashboard" }, { icon: "ti-pencil", label: "Testlar", pg: "tests" }, { icon: "ti-award", label: "Kompetensiya profili", pg: "profile" }, { icon: "ti-world", label: "Foydali resurslar", pg: "resources" }, { icon: "ti-chart-bar", label: "Statistika", pg: "stats" }];
    return (
      <div style={{ width: 240, minWidth: 240, background: "linear-gradient(160deg,#1e3a8a 0%,#1e40af 60%,#2563eb 100%)", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ width: 44, height: 44, background: "rgba(255,255,255,0.15)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
            <i className="ti ti-school" style={{ fontSize: 24, color: "#fff" }} />
          </div>
          <div style={{ color: "#fff", fontSize: 17, fontWeight: 500 }}>KompTest</div>
          <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, marginTop: 2 }}>Kasbiy kompetentlik platformasi</div>
        </div>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: "rgba(255,255,255,0.2)", border: "2px solid rgba(255,255,255,0.3)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 14, fontWeight: 500 }}>{initials(user)}</div>
            <div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 500 }}>{user.ism} {user.familiya}</div>
              <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 20, fontWeight: 500, background: isAdmin ? "rgba(251,191,36,0.25)" : "rgba(52,211,153,0.2)", color: isAdmin ? "#fde68a" : "#6ee7b7" }}>{isAdmin ? "Admin" : "Talaba"}</span>
            </div>
          </div>
        </div>
        <nav style={{ flex: 1, padding: "12px 0" }}>
          <div style={{ padding: "6px 20px 4px", fontSize: 10, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Asosiy</div>
          {nav.map((it) => (
            <div key={it.pg} onClick={() => go(it.pg)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 20px", cursor: "pointer", color: page === it.pg ? "#fff" : "rgba(255,255,255,0.65)", fontSize: 14, borderLeft: `3px solid ${page === it.pg ? "#93c5fd" : "transparent"}`, background: page === it.pg ? "rgba(255,255,255,0.14)" : "transparent", transition: "all 0.15s" }}>
              <i className={`ti ${it.icon}`} style={{ fontSize: 19, color: page === it.pg ? "#93c5fd" : "inherit" }} />{it.label}
            </div>
          ))}
        </nav>
        <div style={{ padding: "16px 20px", borderTop: "1px solid rgba(255,255,255,0.1)" }}>
          <div onClick={logout} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", cursor: "pointer", color: "rgba(255,255,255,0.65)", fontSize: 14 }}>
            <i className="ti ti-logout" style={{ fontSize: 19 }} />Chiqish
          </div>
        </div>
      </div>
    );
  };

  const card = (children, extra = {}) => (
    <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 14, padding: "20px 24px", marginBottom: 14, ...extra }}>{children}</div>
  );

  const btn = (label, onClick, primary = false, sm = false) => (
    <button onClick={onClick} style={{ padding: sm ? "7px 14px" : "10px 20px", borderRadius: 10, fontSize: sm ? 13 : 14, cursor: "pointer", border: primary ? "none" : "0.5px solid #e2e8f0", background: primary ? "#1e40af" : "#fff", color: primary ? "#fff" : "#1e293b", display: "inline-flex", alignItems: "center", gap: 7, fontWeight: 500, fontFamily: "Inter, sans-serif" }}>{label}</button>
  );

  const input = (props) => (
    <input {...props} style={{ width: "100%", padding: "10px 14px", border: "0.5px solid #cbd5e1", borderRadius: 10, fontSize: 14, fontFamily: "Inter, sans-serif", outline: "none", ...props.style }} />
  );

  const select = (props, children) => (
    <select {...props} style={{ width: "100%", padding: "10px 14px", border: "0.5px solid #cbd5e1", borderRadius: 10, fontSize: 14, fontFamily: "Inter, sans-serif", background: "#fff", ...props.style }}>{children}</select>
  );

  const metric = (label, value, iconClass, iconColor, iconBg, sub = "") => (
    <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 12, padding: "16px 18px" }}>
      <div style={{ width: 36, height: 36, background: iconBg, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
        <i className={`ti ${iconClass}`} style={{ fontSize: 18, color: iconColor }} />
      </div>
      <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4, fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 500, color: "#0f172a", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>{sub}</div>}
    </div>
  );

  if (page === "login") return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f1f5f9" }}>
      <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 20, padding: "36px 40px", width: 420 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 60, height: 60, background: "#eff6ff", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
            <i className="ti ti-school" style={{ fontSize: 32, color: "#1e40af" }} />
          </div>
          <div style={{ fontSize: 22, fontWeight: 600, color: "#0f172a" }}>KompTest</div>
          <div style={{ fontSize: 14, color: "#64748b", marginTop: 4 }}>Kasbiy kompetentlikni rivojlantiring</div>
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
          {["student", "admin"].map((r) => (
            <div key={r} onClick={() => setLoginRole(r)} style={{ flex: 1, padding: "10px", border: `0.5px solid ${loginRole === r ? "#3b82f6" : "#e2e8f0"}`, borderRadius: 10, textAlign: "center", cursor: "pointer", fontSize: 14, color: loginRole === r ? "#1e40af" : "#64748b", background: loginRole === r ? "#eff6ff" : "#fff", fontWeight: loginRole === r ? 500 : 400, transition: "all 0.15s" }}>
              <i className={`ti ${r === "student" ? "ti-user" : "ti-settings"}`} style={{ marginRight: 6 }} />{r === "student" ? "Talaba" : "Admin"}
            </div>
          ))}
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, color: "#64748b", marginBottom: 6, fontWeight: 500 }}>Login</div>
          {input({ id: "lu", defaultValue: loginRole === "admin" ? "admin" : "talaba1", placeholder: "Loginni kiriting" })}
        </div>
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: "#64748b", marginBottom: 6, fontWeight: 500 }}>Parol</div>
          {input({ type: "password", defaultValue: "123456", placeholder: "Parolni kiriting" })}
        </div>
        <button onClick={() => doLogin()} style={{ width: "100%", padding: "12px", borderRadius: 10, fontSize: 15, cursor: "pointer", border: "none", background: "#1e40af", color: "#fff", fontWeight: 500, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <i className="ti ti-login" />Kirish
        </button>
        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "16px 0", color: "#64748b", fontSize: 13 }}>
          <div style={{ flex: 1, height: "0.5px", background: "#e2e8f0" }} />yoki<div style={{ flex: 1, height: "0.5px", background: "#e2e8f0" }} />
        </div>
        <button onClick={() => go("register")} style={{ width: "100%", padding: "10px", borderRadius: 10, fontSize: 14, cursor: "pointer", border: "0.5px solid #e2e8f0", background: "#fff", color: "#1e293b", fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <i className="ti ti-user-plus" />Yangi hisob yaratish
        </button>
        <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", marginTop: 14 }}>Demo: istalgan login/parol qabul qilinadi</div>
      </div>
    </div>
  );

  if (page === "register") return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f1f5f9" }}>
      <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 20, padding: "36px 40px", width: 460 }}>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ width: 60, height: 60, background: "#eff6ff", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px" }}>
            <i className="ti ti-user-plus" style={{ fontSize: 32, color: "#1e40af" }} />
          </div>
          <div style={{ fontSize: 22, fontWeight: 600 }}>Ro'yxatdan o'tish</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div><div style={s}>Ism</div>{input({ id: "ri", placeholder: "Ismingiz", style: { marginTop: 6 } })}</div>
          <div><div style={s}>Familiya</div>{input({ id: "rf", placeholder: "Familiyangiz", style: { marginTop: 6 } })}</div>
        </div>
        <div style={{ marginTop: 14 }}><div style={s}>Guruh</div>{input({ id: "rg", placeholder: "Masalan: IT-22", style: { marginTop: 6 } })}</div>
        <div style={{ marginTop: 14 }}><div style={s}>Yo'nalish</div>
          {select({ id: "ry", style: { marginTop: 6 } }, ["Axborot texnologiyalari", "Iqtisodiyot", "Pedagogika", "Huquqshunoslik", "Muhandislik"].map((y) => <option key={y}>{y}</option>))}
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          {btn(<><i className="ti ti-arrow-left" />Orqaga</>, () => go("login"))}
          {btn(<><i className="ti ti-check" />Ro'yxatdan o'tish</>, () => {
            const i = document.getElementById("ri")?.value;
            const f = document.getElementById("rf")?.value;
            const g = document.getElementById("rg")?.value;
            const y = document.getElementById("ry")?.value;
            setUser({ ism: i || "Foydalanuvchi", familiya: f || "Namunavi", guruh: g, yonalish: y });
            setRole("student"); setPage("dashboard");
          }, true)}
        </div>
      </div>
    </div>
  );

  const pub = tests.filter((t) => t.published);
  const mr = myResults();
  const allUsers = [...new Set(results.map((r) => r.userId))];
  const topUsers = allUsers.map((u) => { const ur = results.filter((r) => r.userId === u); return { name: u, avg: ur.length ? Math.round(ur.reduce((a, b) => a + b.pct, 0) / ur.length) : 0, cnt: ur.length }; }).sort((a, b) => b.avg - a.avg).slice(0, 10);

  const PageContent = () => {
    if (page === "dashboard") {
      if (role === "admin") return (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 12, marginBottom: 20 }}>
            {metric("Jami testlar", tests.length, "ti-clipboard-list", "#1e40af", "#dbeafe")}
            {metric("Nashr etilgan", pub.length, "ti-circle-check", "#166534", "#dcfce7")}
            {metric("Ishtirokchilar", results.length, "ti-users", "#5b21b6", "#ede9fe")}
            {metric("Havolalar", links.length, "ti-link", "#92400e", "#fef3c7")}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>Testlar ro'yxati</div>
              {tests.map((t) => <div key={t.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "0.5px solid #f1f5f9", fontSize: 14 }}>
                <div><div>{t.title}</div><div style={{ marginTop: 3 }}>{badge(getComp(t.comp).hex, getComp(t.comp).bg, getComp(t.comp).short)}</div></div>
                {badge(t.published ? "#166534" : "#64748b", t.published ? "#dcfce7" : "#f1f5f9", t.published ? "Nashr" : "Yashirin")}
              </div>)}
            </>)}
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>Kompetensiya taqsimoti</div>
              {COMP_TYPES.map((c) => { const cnt = tests.filter((t) => t.comp === c.id).length; const pct = tests.length ? Math.round((cnt / tests.length) * 100) : 0; return <div key={c.id} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 5 }}><span style={{ color: "#64748b" }}>{c.short}</span><span style={{ fontWeight: 500 }}>{cnt} ta</span></div>
                <div style={{ height: 7, background: "#f1f5f9", borderRadius: 4 }}><div style={{ height: 7, width: `${pct}%`, background: c.hex, borderRadius: 4 }} /></div>
              </div>; })}
            </>)}
          </div>
        </div>
      );
      const done = mr.length, pct = done ? Math.round(mr.reduce((a, b) => a + b.pct, 0) / done) : 0, compDone = [...new Set(mr.map((r) => r.comp))].length;
      return (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 12, marginBottom: 20 }}>
            {metric("Ishlangan testlar", done, "ti-pencil", "#1e40af", "#dbeafe")}
            {metric("O'rtacha ball", `${pct}%`, "ti-chart-bar", "#166534", "#dcfce7")}
            {metric("Kompetensiya", `${compDone}/5`, "ti-award", "#5b21b6", "#ede9fe")}
            {metric("Mavjud testlar", pub.length, "ti-clipboard-list", "#92400e", "#fef3c7")}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 12 }}>Kompetensiya darajasi</div>
              <div style={{ display: "flex", justifyContent: "center", margin: "8px 0 12px" }}>{radarSVG(mr, 130)}</div>
              <div style={{ fontSize: 13, color: "#64748b", textAlign: "center" }}>To'liq profil uchun <span onClick={() => go("profile")} style={{ color: "#1e40af", cursor: "pointer", fontWeight: 500 }}>profilga o'ting →</span></div>
            </>)}
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 12 }}>So'nggi natijalar</div>
              {mr.length === 0 ? <div style={{ textAlign: "center", padding: "30px 0", color: "#94a3b8" }}><i className="ti ti-clipboard-x" style={{ fontSize: 32, display: "block", marginBottom: 8 }} /><div style={{ fontSize: 14 }}>Hali test ishlanmagan</div><button onClick={() => go("tests")} style={{ marginTop: 12, padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13 }}>Testlarga o'tish</button></div> :
                mr.slice(-5).reverse().map((r, i) => <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "0.5px solid #f1f5f9" }}>
                  <div><div style={{ fontSize: 14, fontWeight: 500 }}>{r.title}</div><div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{r.date} · {badge(getComp(r.comp).hex, getComp(r.comp).bg, getComp(r.comp).short)}</div></div>
                  <div style={{ textAlign: "right" }}><div style={{ fontSize: 16, fontWeight: 500, color: r.pct >= 60 ? "#166534" : "#dc2626" }}>{r.pct}%</div><div style={{ fontSize: 12, color: "#64748b" }}>{r.score}/{r.max} ball</div></div>
                </div>)}
            </>)}
          </div>
        </div>
      );
    }

    if (page === "tests") {
      const filtered = pub.filter((t) => (!searchQ || t.title.toLowerCase().includes(searchQ.toLowerCase())) && (!compFilter || t.comp === compFilter));
      return (
        <div>
          <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
            <div style={{ position: "relative", flex: 1 }}>
              <i className="ti ti-search" style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#94a3b8", fontSize: 16 }} />
              <input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Test qidirish..." style={{ width: "100%", padding: "10px 14px 10px 38px", border: "0.5px solid #cbd5e1", borderRadius: 10, fontSize: 14, fontFamily: "Inter, sans-serif", outline: "none" }} />
            </div>
            {select({ value: compFilter, onChange: (e) => setCompFilter(e.target.value), style: { width: 220 } }, [<option key="" value="">Barcha kompetensiyalar</option>, ...COMP_TYPES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)])}
          </div>
          {filtered.length === 0 ? <div style={{ textAlign: "center", padding: 48, color: "#94a3b8" }}><i className="ti ti-clipboard-x" style={{ fontSize: 36, display: "block", marginBottom: 10 }} /><div style={{ fontSize: 14 }}>Test topilmadi</div></div> :
            filtered.map((t) => {
              const done = mr.find((r) => r.testId === t.id);
              return <div key={t.id} style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 14, padding: "18px 20px", marginBottom: 12, cursor: "pointer" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 15, fontWeight: 500, color: "#0f172a", marginBottom: 6 }}>{t.title}</div>
                    <div style={{ fontSize: 13, color: "#64748b", marginBottom: 10 }}>{t.desc}</div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                      {badge(getComp(t.comp).hex, getComp(t.comp).bg, <><i className={`ti ${getComp(t.comp).icon}`} style={{ fontSize: 12 }} />{getComp(t.comp).short}</>)}
                      <span style={{ fontSize: 13, color: "#64748b" }}><i className="ti ti-help-circle" style={{ marginRight: 4 }} />{t.questions.length} savol</span>
                      <span style={{ fontSize: 13, color: "#64748b" }}><i className="ti ti-clock" style={{ marginRight: 4 }} />{t.time} daqiqa</span>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, marginLeft: 16 }}>
                    {done && <div style={{ textAlign: "center" }}><div style={{ fontSize: 20, fontWeight: 500, color: done.pct >= 60 ? "#166534" : "#dc2626" }}>{done.pct}%</div><div style={{ fontSize: 11, color: "#94a3b8" }}>oldingi</div></div>}
                    <button onClick={() => startTest(t.id)} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>{done ? "Qayta ishlash" : "Boshlash"}</button>
                  </div>
                </div>
              </div>;
            })}
        </div>
      );
    }

    if (page === "test-take") {
      const t = activeTest; if (!t) return null;
      const urgent = timeLeft <= 60;
      return (
        <div>
          <div style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 14, padding: "16px 20px", marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 500 }}>{t.title}</div>
              <div style={{ marginTop: 5 }}>{badge(getComp(t.comp).hex, getComp(t.comp).bg, getComp(t.comp).label)}</div>
            </div>
            <div style={{ background: urgent ? "#fef2f2" : "#eff6ff", border: `0.5px solid ${urgent ? "#fecaca" : "#bfdbfe"}`, borderRadius: 10, padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, fontSize: 15, fontWeight: 500, color: urgent ? "#dc2626" : "#1e40af" }}>
              <i className="ti ti-clock" />{fmtTime(timeLeft)}
            </div>
          </div>
          {t.questions.map((q, qi) => {
            const sel = answers[qi] || [];
            return <div key={qi} style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 14, padding: "18px 20px", marginBottom: 12 }}>
              <div style={{ display: "flex", gap: 12, alignItems: "start", marginBottom: 14 }}>
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#1e40af", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 500, flexShrink: 0 }}>{qi + 1}</div>
                <div>
                  <div style={{ fontSize: 15, color: "#0f172a", lineHeight: 1.5 }}>{q.text}</div>
                  <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{q.type === "single" ? "Bitta javob" : q.type === "multi" ? "Bir nechta javob" : "To'g'ri/Noto'g'ri"} · {q.score} ball</div>
                </div>
              </div>
              {q.options.map((opt, oi) => {
                const isSel = sel.includes(oi);
                return <div key={oi} onClick={() => selectOpt(qi, oi, q.type === "multi")} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: isSel ? "#eff6ff" : "#f8fafc", border: `0.5px solid ${isSel ? "#3b82f6" : "#e2e8f0"}`, borderRadius: 10, marginTop: 8, cursor: "pointer", transition: "all 0.15s" }}>
                  <div style={{ width: 18, height: 18, borderRadius: q.type === "multi" ? 5 : "50%", border: `2px solid ${isSel ? "#1e40af" : "#cbd5e1"}`, background: isSel ? "#1e40af" : "#fff", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {isSel && <i className={`ti ${q.type === "multi" ? "ti-check" : "ti-circle-filled"}`} style={{ fontSize: q.type === "multi" ? 12 : 8, color: "#fff" }} />}
                  </div>
                  <span style={{ fontSize: 14, color: "#0f172a" }}>{opt}</span>
                </div>;
              })}
            </div>;
          })}
          <div style={{ display: "flex", gap: 12 }}>
            <button onClick={() => go("tests")} style={{ flex: 1, padding: "11px", borderRadius: 10, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}><i className="ti ti-x" />Bekor qilish</button>
            <button onClick={submitTest} style={{ flex: 2, padding: "11px", borderRadius: 10, border: "none", background: "#1e40af", color: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, fontWeight: 500 }}><i className="ti ti-send" />Testni topshirish</button>
          </div>
        </div>
      );
    }

    if (page === "result") {
      const r = lastResult; if (!r) return null;
      const grade = r.pct >= 85 ? { l: "A'lo", c: "#166534", bg: "#dcfce7" } : r.pct >= 70 ? { l: "Yaxshi", c: "#1e40af", bg: "#dbeafe" } : r.pct >= 55 ? { l: "Qoniqarli", c: "#92400e", bg: "#fef3c7" } : { l: "Qoniqarsiz", c: "#dc2626", bg: "#fee2e2" };
      return (
        <div style={{ maxWidth: 580, margin: "0 auto" }}>
          {card(<>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ width: 130, height: 130, borderRadius: "50%", border: `5px solid ${grade.c}`, background: grade.bg + "30", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                <div style={{ fontSize: 32, fontWeight: 500, color: grade.c }}>{r.pct}%</div>
                <div style={{ fontSize: 12, color: "#64748b" }}>{r.score}/{r.max} ball</div>
              </div>
              <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 10 }}>{r.title}</div>
              <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
                {badge(grade.c, grade.bg, grade.l)}
                {badge(getComp(r.comp).hex, getComp(r.comp).bg, getComp(r.comp).label)}
              </div>
            </div>
            <div style={{ background: "#f8fafc", borderRadius: 12, padding: "16px 18px", marginBottom: 14 }}>
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10 }}>Savol bo'yicha tahlil</div>
              {r.detail.map((d, i) => <div key={i} style={{ padding: "10px 12px", marginBottom: 8, borderRadius: 10, background: d.ok ? "#dcfce7" : "#fee2e2", border: `0.5px solid ${d.ok ? "#86efac" : "#fca5a5"}` }}>
                <div style={{ display: "flex", alignItems: "start", gap: 10 }}>
                  <div style={{ width: 22, height: 22, borderRadius: "50%", background: d.ok ? "#16a34a" : "#dc2626", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <i className={`ti ${d.ok ? "ti-check" : "ti-x"}`} style={{ fontSize: 13, color: "#fff" }} />
                  </div>
                  <div>
                    <div style={{ fontSize: 14, color: d.ok ? "#166534" : "#991b1b", fontWeight: 500 }}>{i + 1}. {d.text}</div>
                    {!d.ok && <div style={{ fontSize: 13, color: "#991b1b", marginTop: 4 }}><strong>To'g'ri javob:</strong> {d.correct.map((c) => d.options[c]).join(", ")}</div>}
                  </div>
                </div>
              </div>)}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => go("tests")} style={{ flex: 1, padding: "10px", borderRadius: 10, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}><i className="ti ti-list" />Testlarga qaytish</button>
              <button onClick={() => go("profile")} style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", background: "#1e40af", color: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}><i className="ti ti-award" />Profilni ko'rish</button>
            </div>
          </>)}
        </div>
      );
    }

    if (page === "profile") return (
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {card(<>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
            <div style={{ width: 54, height: 54, borderRadius: "50%", background: "#dbeafe", border: "2px solid #bfdbfe", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 500, color: "#1e40af" }}>{initials(user)}</div>
            <div><div style={{ fontSize: 16, fontWeight: 500 }}>{user.ism} {user.familiya}</div><div style={{ fontSize: 14, color: "#64748b", marginTop: 2 }}>{user.guruh} {user.yonalish ? "· " + user.yonalish : ""}</div></div>
          </div>
          <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>Kompetensiya darajasi</div>
          {COMP_TYPES.map((c) => { const rs = mr.filter((r) => r.comp === c.id); const avg = rs.length ? Math.round(rs.reduce((a, b) => a + b.pct, 0) / rs.length) : 0; return <div key={c.id} style={{ marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}><i className={`ti ${c.icon}`} style={{ fontSize: 15, color: c.hex }} /><span style={{ fontSize: 13, fontWeight: 500 }}>{c.label}</span></div>
              <div><span style={{ fontSize: 15, fontWeight: 500, color: avg >= 60 ? c.hex : "#dc2626" }}>{avg}%</span><span style={{ fontSize: 12, color: "#64748b", marginLeft: 6 }}>{rs.length} test</span></div>
            </div>
            <div style={{ height: 7, background: "#f1f5f9", borderRadius: 4 }}><div style={{ height: 7, width: `${avg}%`, background: c.hex, borderRadius: 4, transition: "width 0.5s" }} /></div>
          </div>; })}
        </>)}
        <div>
          {card(<>
            <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 12 }}>Radar diagramma</div>
            <div style={{ display: "flex", justifyContent: "center", padding: "8px 0" }}>{radarSVG(mr, 200)}</div>
          </>)}
          {card(<>
            <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 12 }}>Natijalar tarixi</div>
            {mr.length === 0 ? <div style={{ textAlign: "center", padding: "20px", color: "#94a3b8" }}><div style={{ fontSize: 14 }}>Hali test ishlanmagan</div></div> :
              mr.slice().reverse().map((r, i) => <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "0.5px solid #f1f5f9" }}>
                <div><div style={{ fontSize: 14, fontWeight: 500 }}>{r.title}</div><div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{r.date} · {badge(getComp(r.comp).hex, getComp(r.comp).bg, getComp(r.comp).short)}</div></div>
                <div style={{ textAlign: "right" }}><div style={{ fontSize: 16, fontWeight: 500, color: r.pct >= 60 ? "#166534" : "#dc2626" }}>{r.pct}%</div><div style={{ fontSize: 12, color: "#64748b" }}>{r.score}/{r.max}</div></div>
              </div>)}
          </>)}
        </div>
      </div>
    );

    if (page === "resources") return (
      <div>
        {role === "admin" && <div style={{ marginBottom: 16 }}>
          <button onClick={() => setShowAddLink(!showAddLink)} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 7 }}><i className="ti ti-plus" />Havola qo'shish</button>
          {showAddLink && card(<>
            <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>Yangi havola</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <div><div style={s}>Nomi</div>{input({ value: newLink.title, onChange: (e) => setNewLink({ ...newLink, title: e.target.value }), placeholder: "Platforma nomi", style: { marginTop: 6 } })}</div>
              <div><div style={s}>URL</div>{input({ value: newLink.url, onChange: (e) => setNewLink({ ...newLink, url: e.target.value }), placeholder: "https://...", style: { marginTop: 6 } })}</div>
            </div>
            <div style={{ marginBottom: 14 }}><div style={s}>Tavsif</div>{input({ value: newLink.desc, onChange: (e) => setNewLink({ ...newLink, desc: e.target.value }), placeholder: "Qisqacha tavsif", style: { marginTop: 6 } })}</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setShowAddLink(false)} style={{ padding: "8px 16px", borderRadius: 8, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>Bekor</button>
              <button onClick={() => { if (!newLink.title || !newLink.url) return; const clrs = ["#1e40af", "#166534", "#92400e", "#5b21b6", "#9d174d"]; const i = links.length % 5; setLinks([...links, { id: Date.now(), ...newLink, icon: "ti-link", color: clrs[i], bg: clrs[i] + "18" }]); setNewLink({ title: "", url: "", desc: "" }); setShowAddLink(false); }} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>Saqlash</button>
            </div>
          </>)}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {links.map((l) => <a key={l.id} href={l.url} target="_blank" rel="noopener noreferrer" style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", border: "0.5px solid #e2e8f0", borderRadius: 12, background: "#fff", textDecoration: "none", color: "inherit", transition: "all 0.15s" }}>
            <div style={{ width: 42, height: 42, borderRadius: 12, background: l.bg || l.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: l.color, flexShrink: 0 }}><i className={`ti ${l.icon}`} /></div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 15, fontWeight: 500 }}>{l.title}</div><div style={{ fontSize: 13, color: "#64748b", marginTop: 2 }}>{l.desc}</div></div>
            <i className="ti ti-external-link" style={{ fontSize: 16, color: "#94a3b8" }} />
            {role === "admin" && <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); setLinks(links.filter((x) => x.id !== l.id)); }} style={{ padding: "4px 8px", borderRadius: 6, background: "#fee2e2", border: "0.5px solid #fca5a5", color: "#dc2626", cursor: "pointer", fontSize: 12 }}><i className="ti ti-trash" /></button>}
          </a>)}
        </div>
      </div>
    );

    if (page === "stats") {
      const res = role === "admin" ? results : mr;
      const avg = res.length ? Math.round(res.reduce((a, b) => a + b.pct, 0) / res.length) : 0;
      const best = res.length ? Math.max(...res.map((r) => r.pct)) : 0;
      return (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 12, marginBottom: 20 }}>
            {metric("Jami urinishlar", res.length, "ti-list-check", "#1e40af", "#dbeafe")}
            {metric("O'rtacha ball", `${avg}%`, "ti-chart-line", "#166534", "#dcfce7")}
            {metric("Eng yuqori", `${best}%`, "ti-trophy", "#92400e", "#fef3c7")}
            {metric("Ishtirokchilar", allUsers.length, "ti-users", "#5b21b6", "#ede9fe")}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>Test bo'yicha statistika</div>
              {tests.map((t) => { const tr = results.filter((r) => r.testId === t.id); const tavg = tr.length ? Math.round(tr.reduce((a, b) => a + b.pct, 0) / tr.length) : 0; return <div key={t.id} style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 6 }}><span style={{ fontWeight: 500 }}>{t.title}</span><span style={{ color: "#64748b", fontSize: 13 }}>{tr.length} ishtirok · {tavg}%</span></div>
                <div style={{ height: 7, background: "#f1f5f9", borderRadius: 4 }}><div style={{ height: 7, width: `${tavg}%`, background: getComp(t.comp).hex, borderRadius: 4 }} /></div>
                <div style={{ marginTop: 4 }}>{badge(getComp(t.comp).hex, getComp(t.comp).bg, getComp(t.comp).short)}</div>
              </div>; })}
            </>)}
            {card(<>
              <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 14 }}>TOP-10 reyting</div>
              {topUsers.length === 0 ? <div style={{ textAlign: "center", padding: 20, color: "#94a3b8" }}><i className="ti ti-trophy" style={{ fontSize: 32, display: "block", marginBottom: 8 }} /><div style={{ fontSize: 14 }}>Hali natija yo'q</div></div> :
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead><tr>{["#", "Talaba", "O'rtacha", "Testlar"].map((h) => <th key={h} style={{ fontSize: 13, color: "#64748b", fontWeight: 500, padding: "8px 10px", textAlign: "left", borderBottom: "0.5px solid #f1f5f9" }}>{h}</th>)}</tr></thead>
                  <tbody>{topUsers.map((u, i) => <tr key={i}>
                    <td style={{ padding: "9px 10px" }}><div style={{ width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 500, background: i === 0 ? "#fef3c7" : i === 1 ? "#e5e7eb" : i === 2 ? "#fde8d8" : "#f1f5f9", color: i === 0 ? "#92400e" : i === 1 ? "#374151" : i === 2 ? "#9a3412" : "#64748b" }}>{i + 1}</div></td>
                    <td style={{ padding: "9px 10px", fontWeight: 500, fontSize: 14 }}>{u.name}</td>
                    <td style={{ padding: "9px 10px", fontWeight: 500, fontSize: 14, color: u.avg >= 60 ? "#166534" : "#dc2626" }}>{u.avg}%</td>
                    <td style={{ padding: "9px 10px", color: "#64748b", fontSize: 14 }}>{u.cnt}</td>
                  </tr>)}</tbody>
                </table>}
            </>)}
          </div>
        </div>
      );
    }

    if (page === "admin") {
      if (createMode && newTest) {
        const updQ = (i, k, v) => { const qs = [...newTest.questions]; qs[i] = { ...qs[i], [k]: v }; setNewTest({ ...newTest, questions: qs }); };
        const updOpt = (i, oi, v) => { const qs = [...newTest.questions]; qs[i].options[oi] = v; setNewTest({ ...newTest, questions: qs }); };
        const setC = (i, oi, multi) => { const qs = [...newTest.questions]; const cur = qs[i].correct; if (multi) qs[i].correct = cur.includes(oi) ? cur.filter((x) => x !== oi) : [...cur, oi]; else qs[i].correct = [oi]; setNewTest({ ...newTest, questions: qs }); };
        return card(<>
          <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 16 }}>Yangi test yaratish</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div><div style={s}>Test nomi</div>{input({ value: newTest.title, onChange: (e) => setNewTest({ ...newTest, title: e.target.value }), placeholder: "Test nomi", style: { marginTop: 6 } })}</div>
            <div><div style={s}>Kompetensiya</div>{select({ value: newTest.comp, onChange: (e) => setNewTest({ ...newTest, comp: e.target.value }), style: { marginTop: 6 } }, COMP_TYPES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>))}</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
            <div><div style={s}>Vaqt (daqiqa)</div>{input({ type: "number", value: newTest.time, onChange: (e) => setNewTest({ ...newTest, time: +e.target.value }), style: { marginTop: 6 } })}</div>
            <div><div style={s}>Holat</div>{select({ value: newTest.published ? "true" : "false", onChange: (e) => setNewTest({ ...newTest, published: e.target.value === "true" }), style: { marginTop: 6 } }, [<option key="f" value="false">Yashirin</option>, <option key="t" value="true">Nashr etilgan</option>])}</div>
          </div>
          <div style={{ marginTop: 14 }}><div style={s}>Tavsif</div>{input({ value: newTest.desc, onChange: (e) => setNewTest({ ...newTest, desc: e.target.value }), placeholder: "Test tavsifi", style: { marginTop: 6 } })}</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "16px 0 10px" }}>
            <div style={{ fontSize: 14, fontWeight: 500 }}>Savollar ({newTest.questions.length} ta)</div>
            <button onClick={() => setNewTest({ ...newTest, questions: [...newTest.questions, { type: "single", text: "", options: ["", ""], correct: [], score: 2 }] })} style={{ padding: "6px 12px", borderRadius: 8, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 6 }}><i className="ti ti-plus" />Savol qo'shish</button>
          </div>
          {newTest.questions.map((q, i) => <div key={i} style={{ background: "#f8fafc", borderRadius: 12, padding: 16, marginBottom: 10, border: "0.5px solid #e2e8f0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              <div style={{ fontSize: 14, fontWeight: 500 }}>Savol {i + 1}</div>
              <button onClick={() => setNewTest({ ...newTest, questions: newTest.questions.filter((_, j) => j !== i) })} style={{ padding: "4px 8px", borderRadius: 6, background: "#fee2e2", border: "0.5px solid #fca5a5", color: "#dc2626", cursor: "pointer", fontSize: 12 }}><i className="ti ti-trash" /></button>
            </div>
            <div style={{ marginBottom: 10 }}><div style={s}>Savol matni</div>{input({ value: q.text, onChange: (e) => updQ(i, "text", e.target.value), placeholder: "Savol matnini kiriting", style: { marginTop: 6 } })}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
              <div><div style={s}>Tur</div>{select({ value: q.type, onChange: (e) => updQ(i, "type", e.target.value), style: { marginTop: 6 } }, [<option key="s" value="single">Bir javobli</option>, <option key="m" value="multi">Ko'p javobli</option>, <option key="t" value="truefalse">To'g'ri/Noto'g'ri</option>])}</div>
              <div><div style={s}>Ball</div>{input({ type: "number", value: q.score, onChange: (e) => updQ(i, "score", +e.target.value), style: { marginTop: 6 } })}</div>
            </div>
            {q.options.map((opt, oi) => <div key={oi} style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8 }}>
              <input type={q.type === "multi" ? "checkbox" : "radio"} name={`cor${i}`} checked={q.correct.includes(oi)} onChange={() => setC(i, oi, q.type === "multi")} style={{ width: 16, height: 16, accentColor: "#1e40af" }} />
              {input({ value: opt, onChange: (e) => updOpt(i, oi, e.target.value), placeholder: `Variant ${oi + 1}`, style: { height: 34, fontSize: 13 } })}
            </div>)}
            {q.type !== "truefalse" && <button onClick={() => { const qs = [...newTest.questions]; qs[i].options.push(""); setNewTest({ ...newTest, questions: qs }); }} style={{ marginTop: 8, padding: "5px 12px", borderRadius: 6, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 12, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 5 }}><i className="ti ti-plus" />Variant qo'shish</button>}
          </div>)}
          <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
            <button onClick={() => { setCreateMode(false); setNewTest(null); }} style={{ flex: 1, padding: "11px", borderRadius: 10, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}><i className="ti ti-x" />Bekor</button>
            <button onClick={() => { setTests([...tests, { ...newTest, id: Date.now() }]); setCreateMode(false); setNewTest(null); setAdminTab("tests"); }} style={{ flex: 2, padding: "11px", borderRadius: 10, border: "none", background: "#1e40af", color: "#fff", cursor: "pointer", fontSize: 14, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, fontWeight: 500 }}><i className="ti ti-device-floppy" />Saqlash</button>
          </div>
        </>);
      }
      return (
        <div>
          <div style={{ display: "flex", gap: 4, marginBottom: 20, background: "#f1f5f9", borderRadius: 12, padding: 4 }}>
            {["tests", "links"].map((t) => <div key={t} onClick={() => setAdminTab(t)} style={{ flex: 1, padding: "9px 18px", fontSize: 14, cursor: "pointer", borderRadius: 9, fontWeight: 500, textAlign: "center", background: adminTab === t ? "#fff" : "transparent", color: adminTab === t ? "#1e40af" : "#64748b", transition: "all 0.15s" }}>{t === "tests" ? `Testlar (${tests.length})` : `Havolalar (${links.length})`}</div>)}
          </div>
          {adminTab === "tests" ? <>
            <div style={{ marginBottom: 14 }}>
              <button onClick={() => { setCreateMode(true); setNewTest({ title: "", comp: "kasbiy", time: 15, published: false, desc: "", questions: [] }); }} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 7 }}><i className="ti ti-plus" />Yangi test yaratish</button>
            </div>
            {tests.map((t) => <div key={t.id} style={{ background: "#fff", border: "0.5px solid #e2e8f0", borderRadius: 14, padding: "16px 20px", marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{t.title}</div>
                  <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
                    {badge(getComp(t.comp).hex, getComp(t.comp).bg, getComp(t.comp).short)}
                    <span style={{ fontSize: 13, color: "#64748b" }}><i className="ti ti-help-circle" style={{ marginRight: 4 }} />{t.questions.length} savol</span>
                    <span style={{ fontSize: 13, color: "#64748b" }}><i className="ti ti-clock" style={{ marginRight: 4 }} />{t.time} daq</span>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  {badge(t.published ? "#166534" : "#64748b", t.published ? "#dcfce7" : "#f1f5f9", t.published ? "Nashr" : "Yashirin")}
                  <button onClick={() => setTests(tests.map((x) => x.id === t.id ? { ...x, published: !x.published } : x))} style={{ padding: "6px 12px", borderRadius: 8, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>{t.published ? "Yashirish" : "Nashr"}</button>
                  <button onClick={() => setTests(tests.filter((x) => x.id !== t.id))} style={{ padding: "6px 10px", borderRadius: 8, background: "#fee2e2", border: "0.5px solid #fca5a5", color: "#dc2626", cursor: "pointer", fontSize: 13 }}><i className="ti ti-trash" /></button>
                </div>
              </div>
            </div>)}
            {tests.length === 0 && <div style={{ textAlign: "center", padding: 48, color: "#94a3b8" }}><div style={{ fontSize: 14 }}>Hali test yaratilmagan</div></div>}
          </> : <>
            <div style={{ marginBottom: 14 }}>
              <button onClick={() => setShowAddLink(!showAddLink)} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 7 }}><i className="ti ti-plus" />Havola qo'shish</button>
            </div>
            {showAddLink && card(<>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                <div><div style={s}>Nomi</div>{input({ value: newLink.title, onChange: (e) => setNewLink({ ...newLink, title: e.target.value }), placeholder: "Platforma nomi", style: { marginTop: 6 } })}</div>
                <div><div style={s}>URL</div>{input({ value: newLink.url, onChange: (e) => setNewLink({ ...newLink, url: e.target.value }), placeholder: "https://...", style: { marginTop: 6 } })}</div>
              </div>
              <div style={{ marginBottom: 14 }}><div style={s}>Tavsif</div>{input({ value: newLink.desc, onChange: (e) => setNewLink({ ...newLink, desc: e.target.value }), placeholder: "Qisqacha tavsif", style: { marginTop: 6 } })}</div>
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setShowAddLink(false)} style={{ padding: "8px 16px", borderRadius: 8, border: "0.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>Bekor</button>
                <button onClick={() => { if (!newLink.title || !newLink.url) return; const clrs = ["#1e40af", "#166534", "#92400e", "#5b21b6", "#9d174d"]; setLinks([...links, { id: Date.now(), ...newLink, icon: "ti-link", color: clrs[links.length % 5], bg: clrs[links.length % 5] + "18" }]); setNewLink({ title: "", url: "", desc: "" }); setShowAddLink(false); }} style={{ padding: "8px 16px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif" }}>Saqlash</button>
              </div>
            </>)}
            {links.map((l) => <div key={l.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 16px", border: "0.5px solid #e2e8f0", borderRadius: 12, marginBottom: 10, background: "#fff" }}>
              <div style={{ width: 42, height: 42, borderRadius: 12, background: l.bg || l.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: l.color }}><i className={`ti ${l.icon}`} /></div>
              <div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 500 }}>{l.title}</div><a href={l.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 13, color: "#3b82f6" }}>{l.url}</a></div>
              <button onClick={() => setLinks(links.filter((x) => x.id !== l.id))} style={{ padding: "5px 10px", borderRadius: 6, background: "#fee2e2", border: "0.5px solid #fca5a5", color: "#dc2626", cursor: "pointer", fontSize: 12 }}><i className="ti ti-trash" /></button>
            </div>)}
          </>}
        </div>
      );
    }
    return null;
  };

  const topbarActions = () => {
    if (role === "admin" && page === "dashboard") return <button onClick={() => go("admin")} style={{ padding: "7px 14px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 7 }}><i className="ti ti-plus" />Test yaratish</button>;
    if (role === "student" && page === "dashboard") return <button onClick={() => go("tests")} style={{ padding: "7px 14px", borderRadius: 8, background: "#1e40af", color: "#fff", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "Inter, sans-serif", display: "flex", alignItems: "center", gap: 7 }}><i className="ti ti-pencil" />Testlarga o'tish</button>;
    return null;
  };

  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9", fontFamily: "Inter, sans-serif" }}>
      <div style={{ display: "flex", minHeight: "100vh" }}>
        <Sidebar />
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "0 28px", height: 64, background: "#fff", borderBottom: "0.5px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ fontSize: 18, fontWeight: 500, color: "#0f172a" }}>{PAGE_TITLES[page]}</div>
            </div>
            <div>{topbarActions()}</div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "24px 28px" }}>
            <PageContent />
          </div>
        </div>
      </div>
    </div>
  );
}
